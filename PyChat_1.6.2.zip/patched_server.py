import socket, time

print("WELCOME TO PyChat Server!")
print(" _______              ______   __                    __             ______                                                    ")
print("/       \            /      \ /  |                  /  |           /      \                                                   ")
print("$$$$$$$  | __    __ /$$$$$$  |$$ |____    ______   _$$ |_         /$$$$$$  |  ______    ______   __     __  ______    ______  ")
print("$$ |__$$ |/  |  /  |$$ |  $$/ $$      \  /      \ / $$   |        $$ \__$$/  /      \  /      \ /  \   /  |/      \  /      \ ")
print("$$    $$/ $$ |  $$ |$$ |      $$$$$$$  | $$$$$$  |$$$$$$/         $$      \ /$$$$$$  |/$$$$$$  |$$  \ /$$//$$$$$$  |/$$$$$$  |")
print("$$$$$$$/  $$ |  $$ |$$ |   __ $$ |  $$ | /    $$ |  $$ | __        $$$$$$  |$$    $$ |$$ |  $$/  $$  /$$/ $$    $$ |$$ |  $$/ ")
print("$$ |      $$ \__$$ |$$ \__/  |$$ |  $$ |/$$$$$$$ |  $$ |/  |      /  \__$$ |$$$$$$$$/ $$ |        $$ $$/  $$$$$$$$/ $$ |      ")
print("$$ |      $$    $$ |$$    $$/ $$ |  $$ |$$    $$ |  $$  $$/       $$    $$/ $$       |$$ |         $$$/   $$       |$$ |      ")
print("$$/        $$$$$$$ | $$$$$$/  $$/   $$/  $$$$$$$/    $$$$/         $$$$$$/   $$$$$$$/ $$/           $/     $$$$$$$/ $$/       ")
print("          /  \__$$ |                                                                                                          ")
print("         $$    $$/                                                                                                           ")
print("           $$$$$$/ ")

print("[Server] :: Server started")
host = socket.gethostbyname(socket.gethostname())
print("[Server] :: Getting IPv4 Adress")
print("[Server] :: Server ip:" + str(host))
port = 9090
print("[Server] :: Getting port")
clients = []
print("[Server] :: Init server chatroom")
s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
s.bind((host,port))
print("[Server] :: Setup setings")

quit = False
print("[Server] :: Setup is OK")
#banlist = open('banlist.txt','rt')
while not quit:
	try:
		data, addr = s.recvfrom(1024)
                
                if addr not in clients:
                        for ban in banlist.readlines():
                                if str(addr) == ban:
                                        s.sendto('/banned',addr)
                                        print('banned')
                                else:
                                        clients.append(addr)
		itsatime = time.strftime("%Y-%m-%d-%H.%M.%S", time.localtime())

		print("["+addr[0]+"]=["+str(addr[1])+"]=["+itsatime+"]/",end="")
		print(data.decode("utf-8"))

		for client in clients:
			if addr != client:
				s.sendto(data,client)
	except:	
		print("\n[Server] :: Server stoped")
		quit = True
		
s.close()
