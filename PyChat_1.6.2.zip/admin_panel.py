#PyChat admin panel v1.1

import random,os

com1=True

while com1:
    print('1. Work with db')
    print('2. See banned users')
    print('3. Ban user')
    print('4. Clean banlist.txt')
    print('5. Exit')
    com = input('>')
    if com == '1':
        print('1. See db')
        print('2. Dump user')
        print('3. Dump user port')
        print('4. Clean db')
        com2=input('>')
        if com2 == '1':
            db=open('clients.db')
            print(db.read())
            db.close()
        if com2 == '2':
            user = input('User ip:')
            user = '['+user+']'
            db=open('clients.db')
            ih=0
            for i in db.readlines():
                if i.split('=')[0] == user:
                    print(i)
                    ih=ih+1
            if ih==0:
                print('User with ip: '+user+' not found')
        if com2=='3':
            user = input('User port:')
            user = '['+user+']'
            db=open('clients.db')
            ih=0
            for i in db.readlines():
                if i.split('=')[1] == user:
                    print(i)
                    ih=ih+1
            if ih==0:
                print('User with port: '+user+' not found')
        if com2 == '4':
            db=open('clients.db','w')
            db.close()
            print('Db succeful cleaned!')
    if com == '2':
        banned=open('banlist.txt')
        print(banned.read())
    if com == '3':
        banned=open('banlist.txt')
        dump=banned.read()
        banned.close()
        banned=open('banlist.txt','w')
        banned.write(dump)
        ip=input('User ip:')
        reason=input('Ban reason:')
        banned.write(ip+'='+reason+'\n')
        banned.close()
        print('User succeful banned!')
    if com == '4':
        b=open('banlist.txt','w')
        b.close()
        print('Banlist succeful cleaned!')
    if com=='5':
        com1=False
        quit()
    
