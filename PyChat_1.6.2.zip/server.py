import socket, time

print("WELCOME TO PyChat Server! v: 1.6 beta unstable!!!")
print(" _______              ______   __                    __             ______                                                    ")
print("/       \            /      \ /  |                  /  |           /      \                                                   ")
print("$$$$$$$  | __    __ /$$$$$$  |$$ |____    ______   _$$ |_         /$$$$$$  |  ______    ______   __     __  ______    ______  ")
print("$$ |__$$ |/  |  /  |$$ |  $$/ $$      \  /      \ / $$   |        $$ \__$$/  /      \  /      \ /  \   /  |/      \  /      \ ")
print("$$    $$/ $$ |  $$ |$$ |      $$$$$$$  | $$$$$$  |$$$$$$/         $$      \ /$$$$$$  |/$$$$$$  |$$  \ /$$//$$$$$$  |/$$$$$$  |")
print("$$$$$$$/  $$ |  $$ |$$ |   __ $$ |  $$ | /    $$ |  $$ | __        $$$$$$  |$$    $$ |$$ |  $$/  $$  /$$/ $$    $$ |$$ |  $$/ ")
print("$$ |      $$ \__$$ |$$ \__/  |$$ |  $$ |/$$$$$$$ |  $$ |/  |      /  \__$$ |$$$$$$$$/ $$ |        $$ $$/  $$$$$$$$/ $$ |      ")
print("$$ |      $$    $$ |$$    $$/ $$ |  $$ |$$    $$ |  $$  $$/       $$    $$/ $$       |$$ |         $$$/   $$       |$$ |      ")
print("$$/        $$$$$$$ | $$$$$$/  $$/   $$/  $$$$$$$/    $$$$/         $$$$$$/   $$$$$$$/ $$/           $/     $$$$$$$/ $$/       ")
print("          /  \__$$ |                                                                                                          ")
print("         $$    $$/                                                                                                           ")
print("           $$$$$$/ ")

print("[Server] :: Server started")
host = socket.gethostbyname(socket.gethostname())
print("[Server] :: Getting IPv4 Adress")
print("[Server] :: Server ip:" + str(host))
port = 9090
print("[Server] :: Getting port")
clients = []
print("[Server] :: Init server chatroom")
s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
s.bind((host,port))
print("[Server] :: Setup setings")

quit = False
print("[Server] :: Setup is OK")
#banlist=open('banlist.txt')
class db():
    def write(text,dbname):
        db=open(dbname+'.db')
        dump=db.read();
        db.close()
        db=open(dbname+'.db','w')
        db.write(dump)
        db.write(text+'\n')
        db.close()
    def dumpall(dbname):
        db=open(dbname+'.db')
        dump=db.read();
        db.close()
        return dump
    def dumpip(ip,dbname):
        db=open(dbname+'.db')
        for i in db.readlines():
            if i.split('=')[1]==ip:
                print(i)
    def createdb(dbname):
        dbname=dbname+'.db'
        db=open(dbname,'w+')
        db.close()
#databasename='clients'
#db.createdb(databasename)
while not quit:
    try:
                data, addr = s.recvfrom(1024)
                '''
                for ban in banlist.readlines():
                        if str(addr[1]) == ban:
                            print('banned')
                            d='/banned'
                            s.sendto(d.encode('utf-8'),addr)
                '''
                if addr not in clients:
                    clients.append(addr)
                            
                databasename='clients'
                itsatime = time.strftime("%Y-%m-%d-%H.%M.%S", time.localtime())
                com = data.decode('utf-8')
                '''
                if com[1] == '!':
                    print('alarm')
                    data = 'ALARM! :: '+com.split('!')[1]
                    data=data.encode('utf-8')
                if com[1] == '?':
                    rules=open('rules.txt')
                    data = rules.read()
                    data=data.encode('utf-8')
                '''
                print("["+addr[0]+"]=["+str(addr[1])+"]=["+itsatime+"]/",end="")
                print(com)
                for client in clients:
                    if addr != client:
                        s.sendto(data,client)
                db.write("["+addr[0]+"]=["+str(addr[1])+"]=["+itsatime+"]/"+str(data.decode('utf-8')),'clients')
                
    except:
       for client in clients:
           if addr != client:
               s.sendto(data,client)
                   
       #db.write(com.split(':'[0]),addr[0],com.split(':')[2],'unkown',databasename)
                
                
s.close()
