import socket, threading, time

key = 8194

shutdown = False
join = False

print("WELCOME TO PyChat")
print(" _______              ______   __                    __     ")
print("/       \            /      \ /  |                  /  |    ")
print("$$$$$$$  | __    __ /$$$$$$  |$$ |____    ______   _$$ |_   ")
print("$$ |__$$ |/  |  /  |$$ |  $$/ $$      \  /      \ / $$   |  ")
print("$$    $$/ $$ |  $$ |$$ |      $$$$$$$  | $$$$$$  |$$$$$$/   ")
print("$$$$$$$/  $$ |  $$ |$$ |   __ $$ |  $$ | /    $$ |  $$ | __ ")
print("$$ |      $$ \__$$ |$$ \__/  |$$ |  $$ |/$$$$$$$ |  $$ |/  |")
print("$$ |      $$    $$ |$$    $$/ $$ |  $$ |$$    $$ |  $$  $$/ ")
print("$$/        $$$$$$$ | $$$$$$/  $$/   $$/  $$$$$$$/    $$$$/  ")
print("          /  \__$$ |  ")                                      
print("          $$    $$/  ")                                       
print("           $$$$$$/")                                          
print("By: Tikhon Sherstobitov")

def receving (name, sock):
        while not shutdown:
                try:
                        while True:
                                data, addr = sock.recvfrom(1024)
                                #print(data.decode("utf-8"))

                                # Begin
                                decrypt = ""; k = False
                                for i in data.decode("utf-8"):
                                        if i == ":":
                                                k = True
                                                decrypt += i
                                        elif k == False or i == " ":
                                                decrypt += i
                                        else:
                                                decrypt += chr(ord(i)^key)
                                if data.decode("utf-8") == '/banned':
                                     print('You has banned on this server!')
                                     rT.join()
                                     s.close()
                                     exit()
                                print(decrypt)
                                # End

                                time.sleep(0.2)
                except:
                        pass
host = socket.gethostbyname(socket.gethostname())
port = 0

getip = ""
getport = ""
'''
ct=input("Custom setings/Standart setings(Only for test!)?:")

if ct == "Custom setings":
        print("test ip = 127.0.1.1")
        getip = input("server IP = ")
        print("test port = 9090")
        getport = input("Server Pprt = ")
if ct == "Standart setings":
        getip = "127.0.1.1"
        getport = 9090
server = (str(getip),int(getport))
'''
count = 1
server_list = open('server.txt')
for server in server_list.readlines():
        print(str(count)+'. Name: '+' Ip:'+server.split('=')[1]+' Port:'+server.split('=')[2])
        count=count+1
ct = input('Serer:')
getip = server.split('=')[1]
getport = server.split('=')[2]
s = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
s.bind((host,port))
s.setblocking(0)

alias = input("Name: ")

server = (str(getip),int(getport))

rT = threading.Thread(target = receving, args = ("RecvThread",s))
rT.start()

while shutdown == False:
        if join == False:
                s.sendto(("["+alias + "] => join chat ").encode("utf-8"),server)
                join = True
        else:
                try:
                        message = input()
                        try:
                            if message.split(':')[0] == 'ban':
                                s.sendto('/banned:banned by admin!',(message.split(':')[1],message.split(':')[2]))
                                message='User with ip: '+message.split(':')[1]+' has banned!'
                        # Begin
                        crypt = ""
                        for i in message:
                                crypt += chr(ord(i)^key)
                        message = crypt
                        
                        # End

                        if message != "":
                                s.sendto(("["+alias + "] :: "+message).encode("utf-8"),server)
                        
                        time.sleep(0.2)
                except:
                        s.sendto(("["+alias + "] <= left chat ").encode("utf-8"),server)
                        shutdown = True

rT.join()
s.close()
